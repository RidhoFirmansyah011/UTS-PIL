<?php $__env->startSection('title', 'Groups'); ?>

<?php $__env->startSection('content'); ?>

<form action="/groups/addmember/<?php echo e($group->id); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label for="exampleInputEmail1" style="background-color: #ffffff">Nama Teman</label>
        <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
    Pilih Teman
  </button>
  <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="dropdownMenuButton2">
    <select class="form-select" aria-label="Default select example" name="friend_id"> 
    
    <?php $__currentLoopData = $friend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($f->id); ?>"><?php echo e($f->nama); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        <select class="form-select" aria-label="Default select example">
 
</div>
<br>
<br>
            <div class="mb-3"></div>
    <button type="submit" class="btn btn-primary">Tambah ke grup</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelketiga-main\resources\views/groups/addmember.blade.php ENDPATH**/ ?>