<?php $__env->startSection('title', 'Groups'); ?>

<?php $__env->startSection('content'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<a href="/groups/create" class="btn btn-primary">Add Groups</a>
    <div class="row mt-3">
		<div class="col-md-6">

<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card border-success" style="width: 18rem;">
<div class="card-header">
<a href="/groups/<?php echo e($group['id']); ?>" style="background-color: #ffffff"><?php echo e($group['name']); ?></a>
  </div>
    <div class="card-body">
        
        <ul class="list-group list-group-flush">
            <li class="list-group-item"><?php echo e($group['description']); ?></li>
        </ul>
        <hr>
        <a href="/groups/addmember/<?php echo e($group['id']); ?>" class="btn btn-primary">Tambah Member</a>
      
        <ul class="list-group">
        <?php $__currentLoopData = $group->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
  <li class="list-group-item d-flex justify-content-between align-items-center">
  <a href="/friends/<?php echo e($friend['id']); ?>" class="card-title"><i class="fa fa-address-card" aria-hidden="true">
  </i><?php echo e($friend['nama']); ?></a>
  
  
  <form action="/groups/deleteaddmember<?php echo e($friend->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <button type="submit" class="btn btn-danger">X</button>
        </form>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
       
        <hr>
        <li class="list-group-item">Total Member  : 3</li>
        <li class="list-group-item">Member  Masuk : <?php echo e($friend['id']); ?></li>
        <li class="list-group-item">Member Keluar : <?php echo e($group['id']); ?></li>
        <hr>
        <a href="/groups/<?php echo e($group['id']); ?>/edit" class="btn btn-warning">Edit Group</a>
        <form action="/groups/<?php echo e($group['id']); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button class="btn btn-danger">Delete Group</button>
        </form>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
<div class="row mt-3">
		<div class="col-md-6">
<?php echo e($groups->links()); ?>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelketiga-main - Copy\resources\views/groups/index.blade.php ENDPATH**/ ?>